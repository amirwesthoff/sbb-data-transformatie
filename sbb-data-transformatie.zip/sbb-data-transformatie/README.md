# uwv-data-transformatie

In deze repo/dit project staan de mappings en output van de transformatie van UWV-data naar RDF. Omdat de CNL-ontologie nog niet vaststaat, zijn de transformaties eveneens iteratieve pogingen en kan er nog gewijzigd worden in de mappingsregels. Deze pagina zal ook worden voorzien van commentaar en ervaringen om anderen eventueel te helpen.

## (Voorlopig) getransformeerd

| Bestandsnaam input | Bestandsnaam output | Inhoud | Gedaan? |
| --- | --- | --- | --- |
| UWV_BEROEP_KERNBEROEP_ISCO_23.2.xlsx | [kernberoepen+referentieberoepen+isco.ttl](https://ci.tno.nl/gitlab/vmv/data/uwv-data-transformatie/-/blob/main/output/kernberoepen+referentieberoepen+isco.ttl) | Beroepen (met mapping naar ISCO) | Ja |
| UWV_BEROEPEN_23.2.xlsx | [referentieberoepen+verbijzonderingen.ttl](https://ci.tno.nl/gitlab/vmv/data/uwv-data-transformatie/-/blob/main/output/referentieberoepen+verbijzonderingen.ttl) | Beroepen (met synoniemen en verbijzonderingen) | Ja |
| UWV_BEROEP_SKILLS_SCORE_23.2.xlsx | [beroepen+skills+score.ttl](https://ci.tno.nl/gitlab/vmv/data/uwv-data-transformatie/-/blob/main/output/beroepen+skills+score.ttl) | Skills gerelateerd aan beroepen | Ja |
| UWV_SKILLS_DEFINITIES.xlsx | [skills+definities.ttl](https://ci.tno.nl/gitlab/vmv/data/uwv-data-transformatie/-/blob/main/output/skills+definities.ttl) | Skills met definities en toelichtingen | Ja |
| UWV_BEROEP_SUBSECTOREN_23.2.xlsx | [beroepen+subsectoren.ttl](https://ci.tno.nl/gitlab/vmv/data/uwv-data-transformatie/-/blob/main/output/beroepen+subsectoren.ttl) | Subsectoren en relaties vanuit beroepen | Ja  |
| UWV_TAKEN_HIERARCHIE.xlsx | [taken.ttl](https://ci.tno.nl/gitlab/vmv/data/uwv-data-transformatie/-/blob/main/output/taken.ttl) | Taken en relaties met ISCO S-vaardigheden | Ja |
| UWV_TAKEN_KERNBEROEP.xlsx | [taken+kernberoepen.ttl](https://ci.tno.nl/gitlab/vmv/data/uwv-data-transformatie/-/blob/main/output/taken+kernberoepen.ttl) | Relaties tussen taken en kernberoepen | Ja |

## Commentaar/ervaringen

| Datum | Naam | Commentaar/ervaringen | Status |
| --- | --- | --- | --- |
| 2023-08-02 | Amir Westhoff | `UWV_BEROEPEN_23.2.xlsx` heeft twee keer `BEROEP_TYPE` als kolomnaam. Ik heb er eentje aangepast naar `BEROEP_TYPE_HGR` om onderscheid te kunnen maken. (2023-08-21, ID: inmiddels ook aangepast.) | Besproken, wordt aangepast. |
| 2023-08-02 | Amir Westhoff |  In `UWV_BEROEP_KERNBEROEP_ISCO_23.2.xlsx` zie ik dat sommige waardes in kolom `CODE_UG` eigenlijk moeten beginnen met een `0` (bijv. `0110` in plaats van `110`). Het zou goed zijn als deze `0` in de brondata goed staat, zodat het construeren van ISCO-URI's (bijv. `http://data.europa.eu/esco/isco/C0110`) makkelijker is. (2023-08-21, ID/JB: eens, wordt aangepast.) | Dit is op dit moment **niet** gefixt in de getransformeerde RDF. Besproken, wordt aangepast. |
| 2023-08-02 | Amir Westhoff |  Doordat we gezegd hebben dat er maar één klasse is voor Beroep (`cnl:Beroep`), lijken er in sommige gevallen codes/identifiers te botsen omdat ze dan niet meer uniek zijn: 1104, 12110 en 12195. Dit levert dan ook geen unieke URI's op. (2023-08-21, ID/JB: eens, wordt aangepast.) | Dit is op dit moment **niet** gefixt in de getransformeerde RDF. Besproken, wordt aangepast. | 
| 2023-08-02 | Amir Westhoff | In de brondata hebben synoniemen van beroepen een identifier. In de huidige mappingsregels zijn dit strings geworden als skos:altLabel bij een beroep. Is dit OK? (2023-08-21, ID/JB: voor pilot OK, maar wellicht voor UWV intern gekoppeld aan functionaliteit) | Besproken, in principe OK. | 
| 2023-08-02 | Amir Westhoff | Voor cnl:hasLevel heb ik nu niveau 1, 2 en 3 gehanteerd. Is dit OK? (2023-08-21, ID/JB: eens) | Besproken, in principe OK. |
| 2023-08-02 | Amir Westhoff | Alle beroepen zijn in een skos:ConceptScheme geplaatst (`<http://competentnl.nl/id/conceptscheme/beroepen>`) met cnl:Beroepen van niveau 1 als topconcepten. Is dit OK? (2023-08-21, eens)  | Besproken, in principe OK. |
| 2023-08-02 | Amir Westhoff | In afwachting van consensus over hoe beroepen en skills aan elkaar gerelateerd worden, heb ik dit gedaan met gereificeerde relaties (`cnl:Relatie`), die de score/waardering dragen (`cnl:heeftWaardering`) en wijzen naar beroepen resp. skills (`cnl:heeftBetrekkingOpBeroep` en `cnl:heeftBetrekkingopSkill`). (2023-08-21, ID/JB: eens) | Besproken, in principe OK. |
| 2023-08-02 | Amir Westhoff | Skills zijn onderdeel gemaakt van een `skos:ConceptScheme`, met vooralsnog drie topconcepten (`Softskill`, `Hardskill` en `Kenniselement`), waar iedere Skill naar verwijst. (2023-08-21, ID/JB: OK) | Besproken, in principe OK. |
| 2023-08-02 | Amir Westhoff | Het tabblad in UWV_SKILLS_DEFINITIES.xlsx heet `DEFINITITES` (sic) (2023-08-21, ID/JB: OK, wordt aangepast) | Besproken, wordt aangepast. |
| 2023-08-02 | Amir Westhoff | Subsectoren zijn getransformeerd als instanties van `uwv:Subsector` en geordend in een `skos:ConceptScheme`. Beroepen zijn op basis van `skos:relatedMatch` gerelateerd aan Subsectoren van niveau 2. (2023-08-21, ID/JB: voor nu OK, in ieder geval geen sprake van hierarchie) | Besproken, in principe OK. |
| 2023-08-03 | Amir Westhoff | (1) In `UWV_TAKEN_HIERARCHIE.xlsx` heb ik de URI's opgezocht die horen bij de S-vaardigheden van ESCO. --> vanwege de hertalingen uiteindelijk een CNL-object maken met verwijzingen naar de ESCO URI's? (2023-08-21, ID/JB: Ja, eens) (2) Uit deze exercitie bleek bij een aantal verwijzingen dat de ESCO S-vaardigheden niet meer bestonden: 3.4.3, 4.4.1., 6.4.3., 6.8.0., 6.8.1., 6.8.2., 7.1.3 (2023-08-21, ID/JB: gaan we naar kijken, nu geen oplossing) | Besproken, wordt aangepast. |
| 2023-08-03 | Amir Westhoff | Taken zijn als `uwv:Taak` getransformeerd en geordend in een aparte UWV `skos:ConceptScheme`. (2023-08-21, ID/JB: OK) | Besproken, in principe OK. |
| 2023-08-03 | Amir Westhoff | Omdat de relatie tussen Taken en ESCO S-vaardigheden geen hierarchische relatie is, is `skos:closeMatch` gebruikt. (2023-08-04: Toch wel hierarchische relatie; veranderd naar `skos:broadMatch`)  | Besproken. |
| 2023-08-03 | Amir Westhoff | De relaties tussen Taken en Kernberoepen zijn ook gedaan met gereificeerde relaties (`cnl:Relatie`, `cnl:heeftWaardering`, `cnl:heeftBetrekkingOpBeroep`, `cnl:heeftBetrekkingOpTaak`)  | Besproken, in principe OK. |
| 2023-08-04 | Amir Westhoff | concept UWV-ontologie geupload ter vergelijking  | Besproken, in principe OK. |




