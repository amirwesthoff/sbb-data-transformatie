import subprocess
from tkinter import constants
import pandas as pd
import warnings
import os
import argparse

# Remove warnings from openpyxl
warnings.filterwarnings('ignore', category=UserWarning, module='openpyxl')

def main():

    rml_mappers = ['rmlmapper-5.0.0-all', 'rmlmapper-6.0.0-r363-all.jar']

    # Example command
    # python .\transform.py UWV_TAKEN_HIERARCHIE.xlsx taken turtle [-o]

    # Create the parser
    my_parser = argparse.ArgumentParser(description='Transform data to RDF based on RML for the predefined datatypes and examples')

    # Add the arguments
    my_parser.add_argument('Filename',
                        metavar='filename',
                        type=str,
                        help='the filename of the source file')
    
    my_parser.add_argument('Entity',
                        metavar='datatype',
                        type=str,
                        help='the datatype to select: xml, csv, json or rdb')

    my_parser.add_argument('Format',
                        metavar='format',
                        type=str,
                        help='the output format to select: turtle')
    
    my_parser.add_argument('-o',
                       '--output',
                       action='store_true',
                       help='enable output to file instead of standard out')
    
    # Execute the parse_args() method
    args = my_parser.parse_args()

    # store args in variables
    input_filename = args.Filename
    input_entity = args.Entity
    input_format = args.Format
    input_output = args.output
    
    # Excel to be transformed
    xl = pd.ExcelFile(f'brondata/{input_filename}')

    # Split sheets in Excel file
    sheets = []
    for sheet in xl.sheet_names:
        sheets.append(sheet)
        df = pd.read_excel(xl,sheet_name=sheet, keep_default_na=False)
        df.to_csv(f"brondata/{sheet.lower()}.csv",index=False)

    if input_format not in ('turtle', 'nquads', 'trig', 'trix', 'jsonld'):
        print('Invalid format: turtle, nquads, trig, trix, jsonld.')
    else:
        mapping = f'./mappings/{input_entity}-rml.ttl'

        if input_format == 'turtle':
            extension = 'ttl'
        if input_format == 'nquads':
            extension = 'nq'
        if input_format == 'trig':
            extension = 'trig'
        if input_format == 'trix':
            extension = 'trix'
        if input_format == 'jsonld':
            extension = 'jsonld'
        
        if input_output is False:

            # Run java command to run RMLmapper
            subprocess.call([
                'java', '-jar', 
                rml_mappers[1], 
                '-m', mapping, 
                '-s', input_format, 
                # '--verbose',
                # '-e', f'output/from_{input_datatype}-metadata.{extension}',
                '-l','triple', # dataset - triple - term
            ])
        
        results = f'output/{input_entity}.{extension}'
            
        if input_output is True:

            subprocess.call([
                'java', '-jar', 
                rml_mappers[1], 
                '-m', mapping, 
                '-o', results, 
                '-s', input_format,
            ])
        
        # # Remove sheets 
        for sheet in sheets:
            os.remove(f'./brondata/{sheet.lower()}.csv')

if __name__ == '__main__':
    main()

# java -jar rmlmapper-6.0.0-r363-all.jar mapping -s input_format