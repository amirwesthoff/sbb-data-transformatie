import subprocess
import sys
import argparse

def main():

    # Create the parser
    my_parser = argparse.ArgumentParser(description='Convert YARRRML to RML for the predefined datatypes and examples')

    # # Add the arguments
    # my_parser.add_argument('Datatype',
    #                     metavar='datatype',
    #                     type=str,
    #                     help='the datatype to select: xml, csv, json or rdb')

    # # Execute the parse_args() method
    # args = my_parser.parse_args()

    # input_datatype = args.Datatype
    
    # if input_datatype not in ('xml', 'json', 'csv', 'rdb'):
    #     print('Invalid datatype selected: xml, json, csv or rdb.')
    # else:
    #     mapping_input = f'./mappings/{input_datatype}-yarrrml.yml'
    #     mapping_output = f'./mappings/{input_datatype}-rml.ttl'

    #     # Run Node.js command to convert yaml file to ttl
    #     subprocess.call(["node", "yarrrml-parser/bin/parser.js", "-i", mapping_input, "-o", mapping_output, '--pretty'])

    # Add the arguments
    my_parser.add_argument('Mapping',
                        metavar='mapping',
                        type=str,
                        help='the mapping file')

    # Execute the parse_args() method
    args = my_parser.parse_args()

    input_mapping = args.Mapping

    mapping_input = f'./mappings/{input_mapping}-yarrrml.yml'
    mapping_output = f'./mappings/{input_mapping}-rml.ttl'

    subprocess.call(["node", "yarrrml-parser/bin/parser.js", "-i", mapping_input, "-o", mapping_output, '--pretty'])

if __name__ == '__main__':
    main()

# node yarrrml-parser/bin/parser.js -i .\test_map.yml -o .\test_map-rml.ttl 