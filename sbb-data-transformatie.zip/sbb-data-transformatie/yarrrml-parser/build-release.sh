#!/bin/bash

echo "Nothing to build for NPM packages"
exit 0
